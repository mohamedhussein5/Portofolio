import time
from concurrent.futures import ProcessPoolExecutor
from PIL import Image

def compute_pixel(c, max_iter):
    """
    Calculates the escape time (iteration count) for a single complex number c.
    Formula: z_{n+1} = z_n^2 + c
    """
    z = 0.0j
    for n in range(max_iter):
        if abs(z) > 2.0:
            return n
        z = z * z + c
    return max_iter

def compute_row(args):
    """
    Computes a single horizontal row of pixels for the Mandelbrot set in parallel.
    Args tuple contains: (y, width, height, xmin, xmax, ymin, ymax, max_iter)
    """
    y, width, height, xmin, xmax, ymin, ymax, max_iter = args
    row_pixels = []
    for x in range(width):
        # Map screen pixel coordinates to the complex number plane
        zx = xmin + (x / width) * (xmax - xmin)
        zy = ymin + (y / height) * (ymax - ymin)
        c = complex(zx, zy)
        
        # Determine escape velocity
        color_val = compute_pixel(c, max_iter)
        
        # Map iteration value to an RGB color tuple
        if color_val == max_iter:
            pixel = (0, 0, 0)  # Interior of the set is black
        else:
            shade = int(255 * (color_val / max_iter))
            pixel = (shade, (shade * 5) % 255, 255 - shade)
            
        row_pixels.append(pixel)
    return y, row_pixels

def generate_mandelbrot(width, height, max_iter, num_workers):
    """
    Orchestrates the parallel generation of the Mandelbrot set using a ProcessPoolExecutor.
    """
    xmin, xmax = -2.0, 0.5
    ymin, ymax = -1.25, 1.25
    
    # Prepare arguments for each row in the image grid
    row_args = [
        (y, width, height, xmin, xmax, ymin, ymax, max_iter)
        for y in range(height)
    ]
    
    image = Image.new("RGB", (width, height))
    pixels = image.load()
    
    start_time = time.time()
    
    # Execute computation concurrently or sequentially based on worker count
    if num_workers == 1:
        results = [compute_row(arg) for arg in row_args]
    else:
        with ProcessPoolExecutor(max_workers=num_workers) as executor:
            results = list(executor.map(compute_row, row_args))
            
    end_time = time.time()
    elapsed_time = end_time - start_time
    
    # Assemble computed row pixels into the final image buffer
    for y, row_pixels in results:
        for x, color in enumerate(row_pixels):
            pixels[x, y] = color
            
    return image, elapsed_time

if __name__ == "__main__":
    WIDTH, HEIGHT = 800, 600
    MAX_ITER = 256
    
    print("Running Mandelbrot Parallel Benchmarks...")
    for cores in [1, 2, 4, 8]:
        print(f"Testing with {cores} core(s)...", end="", flush=True)
        img, duration = generate_mandelbrot(WIDTH, HEIGHT, MAX_ITER, num_workers=cores)
        print(f" Completed in {duration:.4f} seconds")
        
        # Save sample output image at 4 cores
        if cores == 4:
            img.save("mandelbrot_output.png")
            print("-> Saved sample output image as 'mandelbrot_output.png'")