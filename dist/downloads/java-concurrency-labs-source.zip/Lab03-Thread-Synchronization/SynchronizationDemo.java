public class SynchronizationDemo {

    static class LetterPrinter {

        public synchronized void printLetters(String threadName) {

            for (char letter = 'A'; letter <= 'Z'; letter++) {
                System.out.println(threadName + " : " + letter);
            }

            System.out.println(threadName + " finished.\n");
        }
    }

    static class Worker extends Thread {

        private final LetterPrinter printer;

        public Worker(LetterPrinter printer, String name) {
            this.printer = printer;
            setName(name);
        }

        @Override
        public void run() {
            printer.printLetters(getName());
        }
    }

    public static void main(String[] args) throws InterruptedException {

        LetterPrinter sharedPrinter = new LetterPrinter();

        Worker thread1 = new Worker(sharedPrinter, "Thread 1");
        Worker thread2 = new Worker(sharedPrinter, "Thread 2");

        thread1.start();
        thread2.start();

        thread1.join();
        thread2.join();

        System.out.println("All threads completed.");
    }
}