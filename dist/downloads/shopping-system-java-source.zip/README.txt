SHOPPING SYSTEM - CSC 2515 / CSC 2517 Project Phase 2
Hussein Musab Abdi (251925406), Mohamed Mohamed Hussein (251925403)

Main class: shoppingsystem.ShoppingSystemApp
Source code: src/shoppingsystem/ (22 .java files)

HOW TO RUN

Option 1 - NetBeans
  File > Open Project > select the ShoppingSystem folder (it opens as a
  Maven project) > right-click ShoppingSystemApp.java > Run File.
  Alternatively: File > New Project > Java with Ant > Java Project with
  Existing Sources, and add the "src" folder.

Option 2 - Ready-made program (Java 8 or later)
  java -jar ShoppingSystem.jar

Option 3 - Command line
  javac -d out src/shoppingsystem/*.java
  java -cp out shoppingsystem.ShoppingSystemApp

SAMPLE DATA
  Customers: C001 Aisha Rahman (MEMBER), C002 Daniel Lee (REGULAR),
             C003 Siti Nur (MEMBER)
  Products : P01 Rice 5kg, P02 Cooking Oil 2L, P03 Milk 1L,
             P04 Chocolate Bar, P05 Detergent 3kg, P06 Notebook A5
  Discounts: members 10%; 5 or more units 5%; the larger one applies.
  Card numbers must have 16 digits (e.g. 4111 1111 1111 1234).

After a successful purchase the receipt is saved as receipt_<number>.txt
in the folder the program runs from.
