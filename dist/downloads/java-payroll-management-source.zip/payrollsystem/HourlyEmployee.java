/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payrollsystem;

/**
 *
 * @author user
 */
public class HourlyEmployee extends Employee {

    private double hourlyWage;
    private double hoursWorked;

    public HourlyEmployee(double hourlyWage, double hoursWorked, String firstname, String lastname, String ssn) {
        super(firstname, lastname, ssn);
        this.hourlyWage = hourlyWage;
        this.hoursWorked = hoursWorked;
    }

    public double getHourlyWage() {
        return hourlyWage;
    }

    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    @Override
    public double earnings() {
        if (hoursWorked <= 40) {
            return hourlyWage * hoursWorked;
        } else {
            return (40 * hourlyWage + (hoursWorked - 40) * hourlyWage * 1.5);
        }
    }

    @Override
    public String toString() {
        return super.toString() + "\nHourly Employee - " + 
               "Hourly Wage: " + hourlyWage + ", Hours worked: " + hoursWorked;
    }
}


