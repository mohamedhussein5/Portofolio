/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payrollsystem;

/**
 *
 * @author user
 */
public class SalariedEmployee extends Employee {

    private double weeklySalary;

    public SalariedEmployee(double weeklySalary, String firstname, String lastname, String ssn) {
        super(firstname, lastname, ssn);
        this.weeklySalary = weeklySalary;
    }

    public double getWeeklySalary() {
        return weeklySalary;
    }

    public void setWeeklySalary(double weeklySalary) {
        this.weeklySalary = weeklySalary;
    }

    @Override
    public double earnings() {
        return weeklySalary;
    }

    @Override
    public String toString() {
        return super.toString() + "\nSalaried Employee - " + 
               "Weekly Salary: " + weeklySalary;
    }
}
    

