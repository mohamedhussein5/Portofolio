/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payrollsystem;

/**
 *
 * @author user
 */
public class Freelancer implements Earnings {
    private String freelancerName;
    private double hoursWorked;
    private double hourlyWage;
    
    public Freelancer(String freelancerName, double hoursWorked, double hourlyWage) {
        this.freelancerName = freelancerName;
        this.hoursWorked = hoursWorked;
        this.hourlyWage = hourlyWage;
    }
    
    public String getFreelancerName() {
        return freelancerName;
    }
    
    public void setFreelancerName(String freelancerName) {
        this.freelancerName = freelancerName;
    }
    
    public double getHoursWorked() {
        return hoursWorked;
    }
    
    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }
    
    public double getHourlyWage() {
        return hourlyWage;
    }
    
    public void setHourlyWage(double hourlyWage) {
        this.hourlyWage = hourlyWage;
    }
    
    @Override
    public double earnings() {
        return hoursWorked * hourlyWage;
    }
    
    @Override
    public String toString() {
        return "Freelancer Information: \n" +
                "name: " + freelancerName +
                "\nHoursWorked: " + hoursWorked +
                "Hourly Wage: " + hourlyWage;
    }
}
