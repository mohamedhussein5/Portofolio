/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payrollsystem;

/**
 *
 * @author user
 */
public class BasePlusCommissionEmployee extends CommissionEmployee {

    private double baseSalary;

    public BasePlusCommissionEmployee(double baseSalary, double grossSales, 
        double commissionRate, String firstname, String lastname, String ssn) {
        super(grossSales, commissionRate, firstname, lastname, ssn);
        this.baseSalary = baseSalary;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }

    @Override
    public double earnings() {
        return (getCommissionRate() * getGrossSales()) + baseSalary;
    }

    @Override
    public String toString() {
        return super.toString() + "\nBase-Salaried Commission Employee - Gross sales: " + baseSalary;
    }
}

