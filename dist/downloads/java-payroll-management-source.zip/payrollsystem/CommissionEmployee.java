/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payrollsystem;

/**
 *
 * @author user
 */
public class CommissionEmployee extends Employee{
    
    private double grossSales;
    private double commissionRate;

    public CommissionEmployee(double grossSales, double commissionRate, String firstname, String lastname, String ssn) {
        super(firstname, lastname, ssn);
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;
    }

    public double getGrossSales() {
        return grossSales;
    }

    public void setGrossSales(double grossSales) {
        this.grossSales = grossSales;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }

    @Override
    public double earnings() {
        return grossSales * commissionRate;
    }

    @Override
    public String toString() {
        return super.toString() + "\nCommission Employee - Gross sales: " + grossSales + 
               ", Commission rate: " + commissionRate;
    }
}

