/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package payrollsystem;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class PayrollSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
        /*SalariedEmployee s = new SalariedEmployee(250, "Ali", "Ahmed", "SSN-123");
        HourlyEmployee h = new HourlyEmployee(10, 41, "John", "Adam", "SSN-444");

        System.out.println(s + "\nEarnings: " + s.earnings() + "\n");
        System.out.println(h + "\nEarnings: " + h.earnings());
        */
       // File: PayrollSystem.java (Updated Main with Enhanced for-loop)

        SalariedEmployee s = new SalariedEmployee(250, "Ali", "Ahmed", "SSN-123");
        HourlyEmployee h = new HourlyEmployee(10, 41, "John", "Adam", "SSN-444");
        CommissionEmployee c = new CommissionEmployee(10000, 0.06, "Sue", "Jones", "SSN-555");
        BasePlusCommissionEmployee b = new BasePlusCommissionEmployee(300, 5000, 0.04, "Bob", "Lewis", "SSN-666");

      
        // Polymorphic standard array of superclass Employee
        Employee[] employees = new Employee[4];
        employees[0] = s;
        employees[1] = h;
        employees[2] = c;
        employees[3] = b;
       

        for (Employee currentEmployee : employees) {
            System.out.println(currentEmployee);
            System.out.println("Earnings: " + currentEmployee.earnings() + "\n");
        }
    }
} 
   

